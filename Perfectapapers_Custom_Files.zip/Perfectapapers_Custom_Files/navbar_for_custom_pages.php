<?php
//include("includes/sessions_check.php");
	if( isset( $_SESSION['user_id'] ) && isset( $_SESSION['user_email'] )  )
{		  
		
			switch($_SESSION['role_id']){
									
						//If User's role_id == 0 then user will be redirected to the User Dashboard
					case 0:
						$Destination_Dashboard_Url = 'User-Dashboard/user-dashboard-index.php';
						break;
						//If User's role_id == 1 then user will be redirected to the Employee Dashboard
					case 1:
						$Destination_Dashboard_Url = 'Emp-Dashboard/emp-dashboard-index.php';
						break;
						//If User's role_id == 2 then user will be redirected to the Admin Dashboard
					case 2:
						$Destination_Dashboard_Url = 'Admin-Dashboard/admin-dashboard-index.php';
						break;
						
									}
		
		
		?>
		

<!-- ****************** Navigation Bar For Logged In Users***************************** -->
<div>
    <nav class="navbar navbar-expand-lg navbar-dark navbar_cutoms">
        <a class="navbar-brand custom_brand" href="https://perfectapapers.com/">Perfectapapers</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
		</button>
		
        <div id="navbarNavDropdown" class="navbar-collapse collapse">
            <ul class="navbar-nav mr-auto">
                <li class="nav-item active">
                    <a class="nav-link" href="https://perfectapapers.com/pricing/">Pricing </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="order-now.php">Order Now</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#">Blogs</a>
				</li>
				<li class="nav-item">
                    <a class="nav-link" href="https://perfectapapers.com/privacy-policy/">Privacy Policy</a>
                </li>
			</ul>
			
            <ul class="navbar-nav">
                <li class="nav-item">
                    <a class="nav-link" target="_blank" href="<?php echo $Destination_Dashboard_Url; ?>"><em class="fa fa-tachometer mr-1"></em>Dashboard</a>
                </li>
                <li class="nav-item">
					<a class="nav-link" href="includes/logout.php?logout_btn=true"><em class="fa fa-power-off mr-1"></em> Logout</a>
                </li>
			</ul>
			
		</div>
		
    </nav>
</div>  
<!-- ******************//Navigation Bar For Logged In Users***************************** -->
		
	<?php  } else{ ?>		


<!-- ******************Navigation Bar For Logged Out Users***************************** -->
<div>
    <nav class="navbar navbar-expand-lg navbar-dark navbar_cutoms">
        <a class="navbar-brand custom_brand" href="https://perfectapapers.com">Perfectapapers</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
		</button>
		
        <div id="navbarNavDropdown" class="navbar-collapse collapse">
            <ul class="navbar-nav mr-auto">
                <li class="nav-item active">
                    <a class="nav-link" href="https://perfectapapers.com/pricing/">Pricing </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="order-now.php">Order Now</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#">Blogs</a>
				</li>
				<li class="nav-item">
                    <a class="nav-link" href="https://perfectapapers.com/privacy-policy/">Privacy Policy</a>
                </li>
			</ul>
			
            <ul class="navbar-nav">
                <li class="nav-item">
                    <a class="nav-link" href="Signup_form.php"><em class="fa fa-user-plus mr-1"></em>Sign Up</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="Login_user.php"><em class="fa fa-sign-in mr-1"></em>Login</a>
                </li>
			</ul>
			
		</div>
		
    </nav>
</div>
<!-- ******************//Navigation Bar For Logged Out Users***************************** -->


<?php  
		}

?>





