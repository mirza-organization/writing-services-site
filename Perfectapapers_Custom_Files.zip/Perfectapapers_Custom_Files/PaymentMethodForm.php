<!--
  Copyright 2018 Square Inc.
  Licensed under the Apache License, Version 2.0 (the "License");
  you may not use this file except in compliance with the License.
  You may obtain a copy of the License at
      http://www.apache.org/licenses/LICENSE-2.0
  Unless required by applicable law or agreed to in writing, software
  distributed under the License is distributed on an "AS IS" BASIS,
  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  See the License for the specific language governing permissions and
  limitations under the License.
-->
<?php
session_start();
function filter_data($input){
	
		  $input = trim($input);
		  $input = stripslashes($input);
		  $input = htmlspecialchars($input);
		  //$input = mysqli_real_escape_string($con ,$input);
		  return $input;
		}

	if( isset( $_GET['P_T_Chk_O_bt'] ) )
				{
					$_SESSION['order_info_row']['order_price'] = filter_data($_SESSION['order_info_row']['order_price']);
				}
?>
<!DOCTYPE html>
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
 <title> Square Payment Processor </title>
 <!-- link to the SqPaymentForm library -->
 <!--<script type="text/javascript" src="https://js.squareupsandbox.com/v2/paymentform"> </script>  -->
 	
 <script type="text/javascript" src="https://js.squareup.com/v2/paymentform">
 </script>	  
 <!-- link to the local custom styles for SqPaymentForm -->
 <link rel="stylesheet" type="text/css" href="mysqpaymentform.css">
</head>
<body>

 <div id="form-container">
   <div id="sq-card-number"></div>
   <div class="third" id="sq-expiration-date"></div>
   <div class="third" id="sq-cvv"></div>
   <div class="third" id="sq-postal-code"></div>
   <button id="sq-creditcard" class="button-credit-card" onclick="onGetCardNonce(event)">Pay $<?php echo $_SESSION['order_info_row']['order_price']; ?>
   </button>
 </div> 
 <!-- end #form-container --> 


 <!-- TODO: Add script from step 1.1.3 -->
 <script type="text/javascript">
         // Create and initialize a payment form object
         const paymentForm = new SqPaymentForm({
         // Initialize the payment form elements
         
 //TODO: Replace with your sandbox application ID if you want to Test PaYments
         applicationId: "sq0idp-xoAXLDLHBF17QxO_t9-GSQ",
         inputClass: 'sq-input',
         autoBuild: false,
       // Customize the CSS for SqPaymentForm iframe elements
       inputStyles: [{
         fontSize: '16px',
         lineHeight: '24px',
         padding: '16px',
         placeholderColor: '#a0a0a0',
         backgroundColor: 'transparent',
       }],
       // Initialize the credit card placeholders
       cardNumber: {
         elementId: 'sq-card-number',
         placeholder: 'Card Number'
       },
       cvv: {
         elementId: 'sq-cvv',
         placeholder: 'CVV'
       },
       expirationDate: {
         elementId: 'sq-expiration-date',
         placeholder: 'MM/YY'
       },
       postalCode: {
         elementId: 'sq-postal-code',
         placeholder: 'Postal'
       },
       // SqPaymentForm callback functions
       callbacks: {
           /*
           * callback function: cardNonceResponseReceived
           * Triggered when: SqPaymentForm completes a card nonce request
           */
           cardNonceResponseReceived: function (errors, nonce, cardData) {
             if (errors) {
               // Log errors from nonce generation to the browser developer console.
               var error_result = '';
               // console.error('Encountered errors:');
               
               errors.forEach(function (error) {
                error_result += error.message+"\n";
                   // console.error('  ' + error.message);
                 });
               // alert('Encountered errors,errors, check browser developer console for more details');
               alert(error_result);
               return;
             }

              // alert(`The generated nonce is:\n${nonce}`);
              // ajax call 
              var xmlhttp = new XMLHttpRequest();
              xmlhttp.onreadystatechange = function() {
                if (this.readyState == 4 && this.status == 200) {
              // console.log(this.responseText);
              alert(this.responseText)
              location.reload();
                // document.getElementById("txtHint").innerHTML = this.responseText;
              }
            };
            xmlhttp.open("GET", "PaymentMethod.php?q=" + nonce, true);
            xmlhttp.send();


              //TODO: Replace alert with code in step 2.1 ,  process-payment
            }
          }
        });
     //TODO: paste code from step 1.1.4


	 //TODO: paste code from step 1.1.5
  paymentForm.build();


     // onGetCardNonce is triggered when the "Pay $1.00" button is clicked
     function onGetCardNonce(event) {

       // Don't submit the form until SqPaymentForm returns with a nonce
       event.preventDefault();
       // Request a nonce from the SqPaymentForm object
       paymentForm.requestCardNonce();
     }
   </script>
 </body>
 </html>


