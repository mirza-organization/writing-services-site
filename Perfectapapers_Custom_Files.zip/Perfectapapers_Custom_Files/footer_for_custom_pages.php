<!-- Footer -->
<footer class="page-footer font-small footer_cutoms pt-4">

  <!-- Footer Elements -->
  <div class="container">

    <!--Grid row-->
    <div class="row">

      <!--Grid column-->
      <div class="col-md-6 mb-4">


      </div>
      <!--Grid column-->

      <!--Grid column-->
      <div class="col-md-6 mb-4">

      </div>
      <!--Grid column-->

    </div>
    <!--Grid row-->

  </div>
  <!-- Footer Elements -->

  <!-- Copyright -->
  <div class="footer-copyright text-center py-3 text-light">© 2019 Copyright:
    <a href="https://perfectapapers.com/" style="color:#ffb606;"> perfectapapers.com</a>
  </div>
  <!-- Copyright -->

</footer>
<!-- Footer -->