	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<meta name="description" content="">
	<meta name="author" content="">
	<link href="../order-images/order-now-favicon.png" rel="icon" type="image/x-icon" />


	<!-- Bootstrap core CSS -->
	<link href="../custom-assets/dist/css/bootstrap.min.css" rel="stylesheet">

	<!-- Icons -->
	<link href="../custom-assets/css-for-dashboards/font-awesome.css" rel="stylesheet">

	<!-- Custom styles for this template -->
	<link href="../custom-assets/css-for-dashboards/style.css" rel="stylesheet">