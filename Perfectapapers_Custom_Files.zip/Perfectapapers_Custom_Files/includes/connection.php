<?php

	class connection{
		
		private $con;
		private $con_last_id;
		
		public function connect_db(){
			
		//$this->con	= new MySQLi('localhost','root','','perfectapapers_db');
		$this->con	= new MySQLi('localhost','perfecta_admin','n;Go%cU4yVx{','perfecta_custom_db');
			
			if( $this->con )
			{	
				return $this->con;
			}
			else{
				die("Error in connecting with the Database" . mysqli_connect_error());
				$this->con->close();
			}
				
	
					}
		
		//When this Function is executed after mysqli_query() it automatically Fetches the last inserted ID :)
		public function get_last_inserted_id(){
			
			 $this->con_last_id = $this->con->insert_id;
			 return $this->con_last_id;
			
					}
	}

?>