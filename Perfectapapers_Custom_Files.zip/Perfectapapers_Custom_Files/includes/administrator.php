<?php 
include_once("super_person.php");

class administrator extends super_person{
	
	public function update_order_payment_status(){
		
				$order_id = $this->filter_data($_POST['order_id']);
				
				$q_result = $this->run_query("UPDATE temp_order_tbl SET payment_status = 'Paid' WHERE order_id = '$order_id'");
				
				return $q_result;
			
	}
	
	
	//Abstract functions must have a body in child classes otherwise a Fatal error would be generated
	public function update_data(){
		
		
	}
	public function insert_data(){
		
		
	}
	public function check_data(){
		
		
	}
	public function delete_data(){
		
		
	}
	
};

?>