<nav class="sidebar col-xs-12 col-sm-4 col-lg-3 col-xl-2">
    <h1 class="site-title"><a href="https://perfectapapers.com/" target="_blank"><em class="fa fa-rocket"></em> Perfect A papers </a></h1>
                                        
    <a href="#menu-toggle" class="btn btn-default" id="menu-toggle"><em class="fa fa-bars"></em></a>
    <ul class="nav nav-pills flex-column sidebar-nav">
        
        <li class="nav-item"><a class="nav-link active" href="user-dashboard-index.php"><em class="fa fa-dashboard"></em> Dashboard <span class="sr-only">(current)</span></a></li>
        
        <li class="nav-item"><a class="nav-link" href="completed-orders.php"><em class="fa fa-calendar-o"></em> completed orders</a></li>
        
        <li class="nav-item"><a class="nav-link" href="orders-in-progress.php"><em class="fa fa-bar-chart"></em> orders in progress</a></li>
        
        <li class="nav-item"><a class="nav-link" href="revisions-in-progress.php"><em class="fa fa-hand-o-up"></em> revisions in progress</a></li>
        <li class="nav-item"><a class="nav-link" href="user-settings.php"><em class="fa fa-pencil-square-o"></em> User Settings</a></li>

    </ul>
</nav>