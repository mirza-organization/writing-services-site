<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="X-UA-Compatible" content="ie=edge">

<!-- Fontawesome Icons it supports 'fa' fontawesome classes-->
<link href="custom-assets/css-for-dashboards/font-awesome.css" rel="stylesheet">

 <!-- BS 4 files links -->
<link rel="stylesheet" href="custom-assets/bootstrap-4.0.0/dist/css/bootstrap.min.css"> 
<script src="custom-assets/jquery-3.2.1.min.js"></script>
<script src="custom-assets/popper.min.js"></script>
<script src="custom-assets/bootstrap-4.0.0/dist/js/bootstrap.min.js"></script>

<link href="order-images/order-now-favicon.png" rel="icon" type="image/x-icon" />

<!-- Custom CSS -->
<link href="custom-css/my-custom-pages-style.css" rel="stylesheet">

