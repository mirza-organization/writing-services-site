
<?php
session_start();
require 'vendor/autoload.php';
$access_token = 'EAAAEAK4EpF3kCyrp--TPzlaUXt7IzGo5fg3-P7imft3GehtVLAgylr306Qb1k57';

# setup authorization
$api_config = new \SquareConnect\Configuration();

// Prodcution Host: https://connect.squareup.com
// Sandbox Host: https://connect.squareupsandbox.com
$api_config->setHost("https://connect.squareup.com");
$api_config->setAccessToken($access_token);
$api_client = new \SquareConnect\ApiClient($api_config);

# create an instance of the Payments API class
$payments_api = new \SquareConnect\Api\PaymentsApi($api_client);
//Test Location ID: A57YBR9RN1YRX  
$location_id = '31ZTG4KARKVGT';
// $nonce = 'cnon:CBASEPzWD9IHIUHS7bTcEhvuJ0A';

$body = new \SquareConnect\Model\CreatePaymentRequest();

$amountMoney = new \SquareConnect\Model\Money();

# Monetary amounts are specified in the smallest unit of the applicable currency.
# This amount is in cents. It's also hard-coded for $1.00, which isn't very useful.

$dollars = $_SESSION['order_info_row']['order_price'];
$cents = $dollars*100;

/*echo $_SESSION['order_info_row']['order_price'];
exit;*/
$amountMoney->setAmount($cents); // set amount
$amountMoney->setCurrency("USD");
$nonce = $_REQUEST["q"];
// echo $q;
// die();
$body->setSourceId($nonce);
$body->setAmountMoney($amountMoney);
$body->setLocationId($location_id);

# Every payment you process with the SDK must have a unique idempotency key.
# If you're unsure whether a particular payment succeeded, you can reattempt
# it with the same idempotency key without worrying about double charging
# the buyer.
$body->setIdempotencyKey(uniqid());

try {
    $result = $payments_api->createPayment($body);
    // print_r($result);
    echo "Your Payment has been made Successfully";
} catch (\SquareConnect\ApiException $e) {
    echo "Exception when calling PaymentsApi->createPayment:";
    var_dump($e->getResponseBody());

}
?>